# World Radar 🌍

Nativní iOS SwiftUI aplikace pro globální počasí a radar.

## Co už umí

- globální mapa přes Apple MapKit
- radarové snímky z celého světa přes RainViewer
- časová osa minulých radarových snímků
- globální hodinová předpověď přes Open-Meteo
- teplota, pocitová teplota, srážky, vlhkost, vítr a nárazy
- hledání měst po celém světě
- aktuální poloha
- přizpůsobení průhlednosti radarové vrstvy
- žádný API klíč

## Důležité

RainViewer aktuálně poskytuje ve svém bezplatném veřejném API historická radarová data, nikoli původní bezplatný nowcast. Aplikace proto kombinuje radarovou historii s předpovědí Open-Meteo místo toho, aby předstírala, že radarová předpověď je aktuální radarové měření.

Open-Meteo je zdarma pro nekomerční použití a vyžaduje atribuci. RainViewer vyžaduje viditelnou atribuci a jeho bezplatné API je určeno pro osobní, vzdělávací a malé komunitní použití.

## Vytvoření projektu v Xcode

1. Otevři Xcode.
2. File → New → Project → iOS → App.
3. Název: `WorldRadar`
4. Interface: SwiftUI
5. Language: Swift
6. Deployment Target: iOS 17.0+
7. Přidej všechny `.swift` soubory z této složky.
8. V projektu nastav `Info.plist` podle přiloženého souboru nebo přidej:
   `Privacy - Location When In Use Usage Description`
9. Spusť na iPhonu nebo simulátoru.

## Licence / atribuce

V aplikaci ponech viditelné:
- Weather data by Open-Meteo.com
- Weather data by RainViewer

Tato verze je připravená jako základ produktu. Pro App Store publikaci je potřeba doplnit vlastní privacy policy, App Store metadata, ikonu a ověřit aktuální podmínky všech datových poskytovatelů.
