import SwiftUI
import MapKit

struct WeatherMapView: UIViewRepresentable {
    @Binding var center: CLLocationCoordinate2D
    @Binding var radarTemplate: String?
    @Binding var radarOpacity: Double

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIView(context: Context) -> MKMapView {
        let map = MKMapView()
        map.delegate = context.coordinator
        map.mapType = .standard
        map.showsCompass = true
        map.showsScale = true
        map.showsUserLocation = true
        map.isRotateEnabled = false

        let region = MKCoordinateRegion(
            center: center,
            latitudinalMeters: 180_000,
            longitudinalMeters: 180_000
        )
        map.setRegion(region, animated: false)
        return map
    }

    func updateUIView(_ map: MKMapView, context: Context) {
        let currentCenter = map.region.center
        if abs(currentCenter.latitude - center.latitude) > 0.01 ||
            abs(currentCenter.longitude - center.longitude) > 0.01 {
            map.setCenter(center, animated: true)
        }

        context.coordinator.updateRadar(on: map, template: radarTemplate, opacity: radarOpacity)
    }

    final class Coordinator: NSObject, MKMapViewDelegate {
        private var radarOverlay: MKTileOverlay?

        func updateRadar(on map: MKMapView, template: String?, opacity: Double) {
            guard let template else {
                if let overlay = radarOverlay {
                    map.removeOverlay(overlay)
                    radarOverlay = nil
                }
                return
            }

            if radarOverlay?.urlTemplate != template {
                if let old = radarOverlay {
                    map.removeOverlay(old)
                }
                let overlay = MKTileOverlay(urlTemplate: template)
                overlay.canReplaceMapContent = false
                overlay.maximumZ = 7
                overlay.minimumZ = 0
                radarOverlay = overlay
                map.addOverlay(overlay, level: .aboveRoads)
            }

            radarOverlay?.alpha = CGFloat(opacity)
        }

        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let tile = overlay as? MKTileOverlay {
                let renderer = MKTileOverlayRenderer(tileOverlay: tile)
                renderer.alpha = tile.alpha
                return renderer
            }
            return MKOverlayRenderer(overlay: overlay)
        }
    }
}
