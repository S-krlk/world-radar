import Foundation

struct WeatherResponse: Decodable {
    let latitude: Double
    let longitude: Double
    let timezone: String
    let current: CurrentWeather
    let hourly: HourlyWeather
}

struct CurrentWeather: Decodable {
    let time: String
    let temperature_2m: Double
    let relative_humidity_2m: Double
    let apparent_temperature: Double
    let precipitation: Double
    let rain: Double
    let weather_code: Int
    let wind_speed_10m: Double
    let wind_direction_10m: Double
    let wind_gusts_10m: Double
}

struct HourlyWeather: Decodable {
    let time: [String]
    let temperature_2m: [Double]
    let apparent_temperature: [Double]
    let precipitation_probability: [Int]
    let precipitation: [Double]
    let rain: [Double]
    let weather_code: [Int]
    let wind_speed_10m: [Double]
    let wind_gusts_10m: [Double]
}

struct RadarFrame: Identifiable, Equatable {
    let id: Int
    let timestamp: Date
    let path: String
}
