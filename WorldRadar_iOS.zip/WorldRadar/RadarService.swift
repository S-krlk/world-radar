import Foundation

final class RadarService {
    static let shared = RadarService()

    private struct Root: Decodable {
        let generated: Int
        let host: String
        let radar: Radar
    }

    private struct Radar: Decodable {
        let past: [Frame]
    }

    private struct Frame: Decodable {
        let time: Int
        let path: String
    }

    func fetchFrames() async throws -> (host: String, frames: [RadarFrame]) {
        let url = URL(string: "https://api.rainviewer.com/public/weather-maps.json")!
        let (data, response) = try await URLSession.shared.data(from: url)
        guard let http = response as? HTTPURLResponse, 200..<300 ~= http.statusCode else {
            throw URLError(.badServerResponse)
        }

        let root = try JSONDecoder().decode(Root.self, from: data)
        let frames = root.radar.past.map {
            RadarFrame(
                id: $0.time,
                timestamp: Date(timeIntervalSince1970: TimeInterval($0.time)),
                path: $0.path
            )
        }
        return (root.host, frames)
    }

    func tileTemplate(host: String, path: String) -> String {
        // Universal Blue is the currently available free RainViewer colour scheme.
        "\(host)\(path)/512/{z}/{x}/{y}/2/1_0.png"
    }
}
