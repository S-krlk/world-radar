import SwiftUI
import CoreLocation
import MapKit

struct ContentView: View {
    @EnvironmentObject private var locationManager: LocationManager

    @State private var coordinate = CLLocationCoordinate2D(latitude: 49.5938, longitude: 17.2509)
    @State private var weather: WeatherResponse?
    @State private var radarFrames: [RadarFrame] = []
    @State private var radarHost = ""
    @State private var selectedFrame = 0
    @State private var radarOpacity = 0.72
    @State private var isLoading = false
    @State private var errorMessage: String?
    @State private var searchText = ""
    @State private var searchedName = "Olomouc"
    @State private var showSearch = false

    var selectedRadarTemplate: String? {
        guard !radarFrames.isEmpty else { return nil }
        let frame = radarFrames[selectedFrame]
        return RadarService.shared.tileTemplate(host: radarHost, path: frame.path)
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            WeatherMapView(
                center: $coordinate,
                radarTemplate: .constant(selectedRadarTemplate),
                radarOpacity: $radarOpacity
            )
            .ignoresSafeArea()

            VStack(spacing: 10) {
                topBar
                Spacer()
                bottomPanel
            }
            .padding(.horizontal, 12)
            .padding(.top, 8)
        }
        .task {
            locationManager.start()
            await refresh()
        }
        .onChange(of: locationManager.coordinate) { _, newValue in
            if let newValue {
                coordinate = newValue
                Task { await refreshWeather() }
            }
        }
        .sheet(isPresented: $showSearch) {
            SearchView(searchText: $searchText) { result in
                searchedName = result.name
                coordinate = result.coordinate
                showSearch = false
                Task { await refreshWeather() }
            }
            .presentationDetents([.medium])
        }
        .alert("Nepodařilo se načíst data", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(errorMessage ?? "")
        }
    }

    private var topBar: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text("WORLD RADAR")
                    .font(.caption.weight(.bold))
                    .tracking(1.4)
                Text(searchedName)
                    .font(.headline)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 9)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))

            Spacer()

            Button {
                showSearch = true
            } label: {
                Image(systemName: "magnifyingglass")
                    .font(.headline)
                    .frame(width: 44, height: 44)
                    .background(.ultraThinMaterial, in: Circle())
            }

            Button {
                locationManager.start()
            } label: {
                Image(systemName: "location.fill")
                    .font(.headline)
                    .frame(width: 44, height: 44)
                    .background(.ultraThinMaterial, in: Circle())
            }
        }
    }

    private var bottomPanel: some View {
        VStack(spacing: 12) {
            if let current = weather?.current {
                HStack {
                    Image(systemName: WeatherCode.symbol(current.weather_code))
                        .font(.system(size: 30))
                    VStack(alignment: .leading) {
                        Text("\(current.temperature_2m, specifier: "%.0f")°")
                            .font(.system(size: 32, weight: .bold))
                        Text(WeatherCode.text(current.weather_code))
                            .font(.subheadline)
                    }

                    Spacer()

                    VStack(alignment: .trailing, spacing: 4) {
                        Label("\(current.wind_speed_10m, specifier: "%.0f") km/h", systemImage: "wind")
                        Label("\(current.relative_humidity_2m, specifier: "%.0f") %", systemImage: "humidity")
                    }
                    .font(.caption)
                }
            }

            if !radarFrames.isEmpty {
                HStack {
                    Text("RADAR")
                        .font(.caption2.weight(.bold))
                    Slider(
                        value: Binding(
                            get: { Double(selectedFrame) },
                            set: { selectedFrame = min(max(Int($0.rounded()), 0), radarFrames.count - 1) }
                        ),
                        in: 0...Double(max(radarFrames.count - 1, 1)),
                        step: 1
                    )
                    Text(frameTime)
                        .font(.caption2.monospacedDigit())
                        .frame(width: 54)
                }

                HStack {
                    Text("Minulost")
                    Spacer()
                    Text("TEĎ")
                    Spacer()
                    Text("Radarová data")
                }
                .font(.caption2)
                .foregroundStyle(.secondary)
            }

            if let hourly = weather?.hourly {
                HourStrip(hourly: hourly)
            }

            HStack {
                Text("Radarová data: RainViewer")
                Spacer()
                Text("Forecast: Open-Meteo")
            }
            .font(.caption2)
            .foregroundStyle(.secondary)
        }
        .padding(16)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))
        .shadow(radius: 10)
    }

    private var frameTime: String {
        guard radarFrames.indices.contains(selectedFrame) else { return "--:--" }
        return radarFrames[selectedFrame].timestamp.formatted(date: .omitted, time: .shortened)
    }

    private func refresh() async {
        isLoading = true
        defer { isLoading = false }

        async let weatherTask: Void = refreshWeather()
        async let radarTask: Void = refreshRadar()

        _ = await (weatherTask, radarTask)
    }

    private func refreshWeather() async {
        do {
            weather = try await WeatherService.shared.fetch(coordinate: coordinate)
        } catch {
            await MainActor.run {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func refreshRadar() async {
        do {
            let result = try await RadarService.shared.fetchFrames()
            await MainActor.run {
                radarHost = result.host
                radarFrames = result.frames
                selectedFrame = max(0, result.frames.count - 1)
            }
        } catch {
            await MainActor.run {
                errorMessage = error.localizedDescription
            }
        }
    }
}

struct HourStrip: View {
    let hourly: HourlyWeather

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(Array(hourly.time.prefix(24).indices), id: \.self) { index in
                    VStack(spacing: 6) {
                        Text(hourly.time[index].suffix(5))
                            .font(.caption2)
                        Image(systemName: WeatherCode.symbol(hourly.weather_code[index]))
                            .frame(height: 20)
                        Text("\(hourly.temperature_2m[index], specifier: "%.0f")°")
                            .font(.headline)
                        if hourly.precipitation_probability[index] > 0 {
                            Text("\(hourly.precipitation_probability[index])%")
                                .font(.caption2)
                                .foregroundStyle(.blue)
                        }
                    }
                    .frame(width: 58)
                }
            }
        }
    }
}

struct SearchView: View {
    @Binding var searchText: String
    let onSelect: (SearchResult) -> Void
    @State private var results: [SearchResult] = []
    @State private var isSearching = false

    var body: some View {
        NavigationStack {
            VStack {
                TextField("Město, země…", text: $searchText)
                    .textFieldStyle(.roundedBorder)
                    .padding()

                List(results) { result in
                    Button {
                        onSelect(result)
                    } label: {
                        VStack(alignment: .leading) {
                            Text(result.name).foregroundStyle(.primary)
                            Text(result.subtitle).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .navigationTitle("Najít místo")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Hledat") {
                        Task { await search() }
                    }
                    .disabled(searchText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isSearching)
                }
            }
            .onSubmit {
                Task { await search() }
            }
        }
    }

    private func search() async {
        isSearching = true
        defer { isSearching = false }

        var components = URLComponents(string: "https://geocoding-api.open-meteo.com/v1/search")!
        components.queryItems = [
            URLQueryItem(name: "name", value: searchText),
            URLQueryItem(name: "count", value: "10"),
            URLQueryItem(name: "language", value: "cs"),
            URLQueryItem(name: "format", value: "json")
        ]

        do {
            let (data, _) = try await URLSession.shared.data(from: components.url!)
            let decoded = try JSONDecoder().decode(GeocodingResponse.self, from: data)
            results = decoded.results?.map {
                SearchResult(
                    name: $0.name,
                    subtitle: [$0.admin1, $0.country].compactMap { $0 }.joined(separator: ", "),
                    coordinate: CLLocationCoordinate2D(latitude: $0.latitude, longitude: $0.longitude)
                )
            } ?? []
        } catch {
            results = []
        }
    }
}

struct GeocodingResponse: Decodable {
    let results: [GeocodingItem]?
}

struct GeocodingItem: Decodable {
    let name: String
    let latitude: Double
    let longitude: Double
    let country: String?
    let admin1: String?
}

struct SearchResult: Identifiable {
    let id = UUID()
    let name: String
    let subtitle: String
    let coordinate: CLLocationCoordinate2D
}
