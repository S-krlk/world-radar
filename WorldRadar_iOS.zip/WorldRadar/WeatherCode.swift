import Foundation

enum WeatherCode {
    static func symbol(_ code: Int) -> String {
        switch code {
        case 0: return "sun.max.fill"
        case 1...3: return "cloud.sun.fill"
        case 45, 48: return "cloud.fog.fill"
        case 51...57: return "cloud.drizzle.fill"
        case 61...67: return "cloud.rain.fill"
        case 71...77: return "snowflake"
        case 80...82: return "cloud.heavyrain.fill"
        case 85...86: return "cloud.snow.fill"
        case 95: return "cloud.bolt.rain.fill"
        case 96, 99: return "cloud.bolt.rain.fill"
        default: return "cloud.fill"
        }
    }

    static func text(_ code: Int) -> String {
        switch code {
        case 0: return "Jasno"
        case 1: return "Převážně jasno"
        case 2: return "Polojasno"
        case 3: return "Zataženo"
        case 45, 48: return "Mlha"
        case 51...57: return "Mrholení"
        case 61...67: return "Déšť"
        case 71...77: return "Sněžení"
        case 80...82: return "Přeháňky"
        case 85...86: return "Sněhové přeháňky"
        case 95: return "Bouřka"
        case 96, 99: return "Bouřka s kroupami"
        default: return "Proměnlivé počasí"
        }
    }
}
